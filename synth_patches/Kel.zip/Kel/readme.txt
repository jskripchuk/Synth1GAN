32 patches for now. Works in synth1 beta 13.(2015-1)

A bit of bread and butter and acoustic emulation, hope you like it. Its a wip.

Cheers. 



