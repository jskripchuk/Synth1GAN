A list of presets in no particular order. The disorginization is because I just started making these for myself, and thought maybe somebody could find them useful. So instead of being ordered, they are color coded. White - leads
Red - keys
Green - basses
Yellow - Synthetic Orchestral/"real" sounds
Purple - Pads and Arps
Blue - FX