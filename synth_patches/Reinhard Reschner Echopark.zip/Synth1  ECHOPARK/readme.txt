Synth1 soundbank by Reinhard Reschner @  Echopark Studio Austria        musicmaker12@gmx.at



This is my first  Soundbank I`ve created for Synth1

Have fun !





This sounds can be copied and used freely but it's not allowed 
to sell them or collect them in a non free library without our 
permission..

