-----------------------------
web:/ www.filtersweep.co.uk
email:/ coxy@blueyonder.co.uk

Synth1 http://www.geocities.jp/daichi1969/softsynth/synth1v107.zip

55 Free trance presets for the Synth1. 
Work in progress, hopefully going to be a bank of 128 patches.
Use as you wish but not for resale. 

If you like, use, hate them, me or my work then please get in touch. I love to hear from everyone!!!

Installation:/ synth1 is a funny creature. Import the FXB into synth1 from your host. They should be imported into ""Sound bank 1"" on Synth1. If that fails goto your synth1 directory and replace soundbank01 with the one here then that should put them in the same place (soundbank 1)

----------------------------

Be good now !

Coxy



:::Bonus:::
+ 73 other Trance Patches!