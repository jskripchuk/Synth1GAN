Welcome2Mac Set created October 2011 with Synth1 v1.12 2010.5   
=========

is a tribute to the Mac Version of Synth1, containing 32 newly programmed Synth1 sounds. Make sure to use the mod wheel for realtime control of the sounds. Note that "Narrowband Lead" is using Pitch Bend for bipolar Filter control.

Copy all files in one of your Synth1 soundbank folders.

For more free synth sounds visit:

http://www.summasounds.de/

Enjoy!
              Summa


=========
Terms of Usage

The Usage within commercial and noncommercial music productions is welcomed...

Please note that a commercial release complete, partly or as part of a library isn't allowed without 
special permission from summasound.de!!! 
A noncommercial release is permitted but sounddesigner and website must be menitoned... 

