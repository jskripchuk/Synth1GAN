-----------------------
- Synth1 v1.07 Bank 3 -
-----------------------

This is a bank of 128 presets.
Mainly electronic/techno sounds.

All these sounds have been made with v1.07alpha2 & v1.07, some presets may not sound like they should in older versions, the presets made with v1.07 (those marked with (*)) also sound different in v1.07alpha.

As in my first and second bank i tried to categorize the sound with the colors :

Dark Blue 	: Lead/Synth/Arp
Light Blue 	: Pad/String/Choir
Red 		: Bass
Yellow 		: Drums
Purple		: "Acoustic Instruments" or Synth
Green 		: FX

I hope you'll like this bank and wish you all love and happiness.

Contact : n0lwenn@netcourrier.com


Nolwenn a.k.a Annabelle

edit 29-nov-2006:
I made some changes (about 7 or 8 patches changed).
