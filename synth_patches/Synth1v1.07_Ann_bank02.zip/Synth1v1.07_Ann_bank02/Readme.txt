-----------------------
- Synth1 v1.07 Bank 2 -
-----------------------

This is a bank of 128 presets.
Essentially techno sounds.

All these sounds have been made with v1.07 alpha2, and they don't sound good in older version.
Most of the sound are not "compatible" with the old version (1.06).

The bank is organized � peu pr�s like this :

32 Trance/Techno/House sounds
32 "Vintage" oldschool sounds
32 Techno/Acid/Agressive stuff
32 Drums/FX

Warning : the preset 81 is a bit loud.
As in my first bank i tried to categorize the sound with the color

Red 		: Bass
Light Blue 	: Pad
Dark Blue 	: Lead/Synth/Arp
Yellow 		: Drums
Purple		: "Acoustic Instruments" 
Green 		: FX



Contact : n0lwenn@netcourrier.com


Nolwenn a.k.a Annabelle
